<template>
  <div class="p-4 bg-light rounded-3">
    <h2 class="h4">Home</h2>
    <p class="mb-0">Public landing page.</p>
  </div>
</template>